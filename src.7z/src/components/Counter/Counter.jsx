import React from 'react'



import minus from "../../img/minus.svg";
import plus from "../../img/plus.svg";
import styles from "./Counter.module.css"

const Counter = (props) => {
  

  // const count = useSelector((state) => state.counter.count)
  // const dispatch = useDispatch()

  const onClickPlusCounter = ()=> {
    
  };
  const onClickMinusCounter = ()=> {
    
  };

  return (
    <div className={styles.add_quantity}>
      <button 
          onClick={onClickMinusCounter}
      className={styles.add_change}>
        <img src={minus} alt="-" />
      </button>
      <div className={styles.add_number}>{props.count}</div>
      <button 
          onClick={onClickPlusCounter}
      className={styles.add_change}>
        <img src={plus} alt="+" />
      </button>
    </div>
  );
};

export default Counter;
