import React from "react";
import { useSelector, useDispatch } from 'react-redux'

import styles from "./CartItem.module.css";
import del from "../../img/x.svg";
import Counter from "../../components/Counter/Counter";
import { addItem, minusItem, plusItem, removeItem } from "../../redux/slices/cartSlise";

const CartItem = (item) => {
  // let [count, setCount] = React.useState(item.count);

    const dispatch = useDispatch()
    const itemId = item.product.id;
    
    const onClickPlus = () =>{
      dispatch(plusItem({
        itemId,
      }),
    );
    };

    const onClickMinus = () =>{
      dispatch(addItem({
        itemId,
      }),
    );
    };



  const onClickRemove = ()=>{
    dispatch(removeItem(item.product.id));
    console.log(`delete ${item.product.id}`);
  };

  return (
    <div className={styles.item}>
        <img className={styles.img} src={`http://localhost:3333${item.product.image}`} alt={item.product.title}/>
      <div className={styles.quantiti}>
        <div className={styles.name}>
          <p className={styles.name}>{item.product.title}</p>
          <button onClick={onClickRemove}>
            <img className={styles.delete} src={del} alt="x" />
          </button>
        </div>
        <div className={styles.quantiti_price}>
          {/* <Counter count={count} setCount={setCount} /> */}
          <Counter onClickPlus={onClickPlus} onClickMinus={onClickMinus} count= {item.count} />
          <p className={styles.price}>
            $
            {item.product.discont_price !== null
                ? item.product.discont_price
                : item.product.price}
            <span className={styles.oldprice}>
              
              {item.product.discont_price == null ? "" : `$ ${item.product.price}`}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
