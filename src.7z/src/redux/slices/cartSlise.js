import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  totalPrice: 0,
  items: [],
};

export const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addItem(state, action) {
      const findItem = state.items.find(
        (product) => product.product.id == action.payload.product.id
      );
      if (findItem) {
        findItem.count++;
      } else {
        state.items.push({
          ...action.payload,
          count: 1,
        });
      }

      state.totalPrice = state.items.reduce((sum, obj) => {
        return obj.product.discont_price == null
          ? obj.product.price * obj.count + sum
          : obj.product.discont_price * obj.count + sum;
      }, 0);
      state.totalItems = state.items.reduce((sum, obj) => {
        return obj.count + sum;
      }, 0);
    },

    plusItem(state, action) {
      const findItem = state.items.find(
        (product) => product.product.id == action.payload.product
      );
      if (findItem) {
        findItem.count++;
      }
    },

    minusItem(state, action) {
      const findItem = state.items.find(
        (product) => product.product.id == action.payload.product
      );
      if (findItem) {
        findItem.count--;
      }
    },

    removeItem(state, action) {
      state.items = state.items.filter(
        (product) => product.product.id !== action.payload
      );
      state.totalPrice = state.items.reduce((sum, obj) => {
        return obj.product.discont_price == null
          ? obj.product.price * obj.count + sum
          : obj.product.discont_price * obj.count + sum;
      }, 0);
    },
  },
});

export const { addItem, plusItem, minusItem, removeItem, clearItems } =
  cartSlice.actions;

export default cartSlice.reducer;
